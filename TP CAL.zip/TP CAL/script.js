/** Calculatrice **/
function calco(){
    var result = document.getElementById('result');
    var data = document.getElementById('data');
    result.innerHTML = "<div id=\"load\" class='loader'></div><br><center>Chargement ...</center><hr>" +
        "<center><b><h3>Resultat</h3></b></center><br><input type='number' id='resultat' placeholder='Resultat...' readonly><br><br>" +
        "<center><div id='di' style='display: none; width: 50%; height: auto; border: 1px solid #004400; background: #00ff55; color: #004400;'></div></center>";
    data.innerHTML = "<center><img src='Img/calc.png' width='100px' height='100px'></center><br><hr><br><br>" +
        "<form>" +
        "<label for='valA'>Nombre 1: </label><input onfocus='init();' type='number' placeholder='Entrez un nombre' id='valA' required><br><br>" +
        "<label for='op'>Choisissez un operateur: </label><select onchange='init();' id='op'>" +
        "<option selected>Addition</option><option>Division</option><option>Multiplication</option><option>Soustraction</option><option>Modulo</option>"+
        "</select><br><br>"+
        "<label for='valB'>Nombre 1: </label><input onfocus='init();' type='number' placeholder='Entrez un nombre' id='valB' required><br><br><hr><br>" +
        "<button type='reset'>Effacer</button> <button id='but' onclick='calculer();' type='submit'>Calculer</button> "
        "</form>";
}
function getSign(){
    var list = document.getElementById('op');
    operat = op.options[op.selectedIndex].innerHTML;
    if(operat === "Addition"){
        return "+";
    }
    else if(operat === "Division"){
        return "/";
    }
    else if(operat === "Multiplication"){
        return "*";
    }
    else if(operat === "Soustraction"){
        return "-";
    }
    else if(operat === "Modulo"){
        return "%";
    }
}
function calculer(){
    var a = document.getElementById('valA').value;
    var b = document.getElementById('valB').value;
    var res = eval(a+getSign()+b);
    document.getElementById('resultat').value = res;
    document.getElementById('di').style.display = 'block';
    document.getElementById('di').innerHTML = 'OK';
}
function init() {
    document.getElementById('di').style.display = 'none';
}

/** Equation RxR **/
function equation(){
    var result = document.getElementById('result');
    var data = document.getElementById('data');
    data.innerHTML = "<center><h3>ax<sup>2</sup>+bx+c = 0</h3></center><br><hr><br><br>" +
        "<form>" +
        "<label for='a'>Entrez la valeur de a: </label><input type='number' placeholder='Entrez un nombre' id='a' required><br><br>" +
        "<label for='b'>Entrez la valeur de b: </label><input type='number' placeholder='Entrez un nombre' id='b' required><br><br>"+
        "<label for='c'>Entrez la valeur de c: </label><input type='number' placeholder='Entrez un nombre' id='c' required><br><br><hr><br>" +
        "<button type='reset'>Effacer</button> <button id='but' onclick='solution();' type='submit'>Resoudre</button> "
    "</form>";
    result.innerHTML = "<div id=\"load\" class='loader'></div><br><center>Chargement ...</center><hr>" +
        "<center><b><h3>Solution</h3></b></center><br><input type='text' id='resultat' placeholder='solution...' readonly><br><br>" +
        "<center><div id='di' style='display: none; width: 50%; height: auto; border: 1px solid #004400; background: #00ff55; color: #004400;'></div></center>";
}

function solution(){
    var av = document.getElementById('a').value;
    var bv = document.getElementById('b').value;
    var cv = document.getElementById('c').value;
    var d = eval(bv*bv - 4*av*cv);
    if(d < 0){
        document.getElementById('di').style.display = 'block';
        document.getElementById('di').innerHTML = "L'equation n'admet pas de solutions dans RxR";
        alert("S = { }");
        document.getElementById('resultat').value = "Ensemble Vide";
    }
    else {
        if (d == 0) {
            var x0 = eval((-1 * bv) / (2 * av));
            document.getElementById('di').style.display = 'block';
            document.getElementById('di').innerHTML = "L'equation admet une solution double dans RxR";
            alert("S = {" + x0 + "}");
            document.getElementById('resultat').value = "S = {" + x0 + "}";
        }
        if (d > 0) {
            document.getElementById('di').style.display = 'block';
            document.getElementById('di').innerHTML = "L'equation admet deux solutions distinctes dans RxR";
            var r1 = -1*parseInt(bv);
            var r2 = 2*parseInt(av);
            var r3 = Math.sqrt(parseInt(d));
            var x1 = (r1-r3)/r2;
            var x2 = (r1+r3)/r2;
            alert("S = {" + x1 + "," + x2 + "}");
            document.getElementById('resultat').value = "S = {" + x1 + "," + x2 + "}";
        }
    }
}

/** Nombre Premier **/
function nPremier(){
    var result = document.getElementById('result');
    var data = document.getElementById('data');
    data.innerHTML = "<center><h3>Les Nombres Premiers</h3></center><br><hr><br><br>" +
        "<form>" +
        "<label for='a'>Entrez un Nombre: </label><input type='number' placeholder='Entrez un nombre' id='num' required><br><br>" +
        "<hr><br>" +
        "<button type='reset'>Effacer</button> <button id='but' onclick='test();' type='submit'>Resoudre</button> "
    "</form>";
    result.innerHTML = "<div id=\"load\" class='loader'></div><br><center>Chargement ...</center><hr>" +
        "<center><div id='di' style='display: none; width: 50%; height: auto; border: 1px solid #004400; background: #00ff55; color: #004400;'></div></center>";
}

function test() {
    var numb = document.getElementById('num');
    var isPremier = 2;
    var val = 0;
    i = 2;
    while(i < numb){
        val = numb%i;
        alert(val);
        i = i + 1;
    }
}